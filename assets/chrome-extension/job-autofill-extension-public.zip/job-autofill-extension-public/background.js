// Service worker:安装时写入默认资料;代理 DeepSeek API 的字段映射请求(避开页面 CORS/CSP)。
importScripts("data/default-profile.js");

chrome.runtime.onInstalled.addListener((details) => {
  chrome.storage.local.get(["jaf_profile", "jaf_settings"], (data) => {
    const seed = {};
    if (!data.jaf_profile) seed.jaf_profile = self.JAF_DEFAULT_PROFILE;
    if (!data.jaf_settings) seed.jaf_settings = self.JAF_DEFAULT_SETTINGS;
    if (Object.keys(seed).length) {
      chrome.storage.local.set(seed, () => {
        if (details.reason === "install") chrome.runtime.openOptionsPage();
      });
    } else if (details.reason === "install") {
      chrome.runtime.openOptionsPage();
    }
  });
});

// 容错解析模型输出(剥 markdown 围栏、提取平衡的 JSON 对象)
function parseModelJson(content) {
  const text = String(content || "")
    .trim()
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
  try {
    return JSON.parse(text);
  } catch {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(text.slice(start, end + 1));
      } catch {
        // fall through
      }
    }
  }
  throw new Error("模型输出不是有效 JSON");
}

const SYSTEM_PROMPT = [
  "你是网申表单字段映射器。输入是一组表单字段(含描述、控件类型、选项)和候选人资料摘要(敏感值已脱敏,但键名可用)。",
  "任务:为每个字段给出映射。三种结果:",
  '1. {"path": "资料键路径"} —— 如 personal.nativePlace、education.0.school、internships.1.role;',
  '2. {"option": "选项文本"} —— 仅当该字段提供了 options 列表且资料能确定应选哪一项时,必须原样返回 options 中的一项;',
  '3. "skip" —— 资料无法确定答案时。宁可 skip 也不要猜。',
  "禁止编造资料中不存在的信息。自我评价、开放问答类字段一律 skip。",
  '输出严格 JSON,不要 Markdown:{"mapping": {"字段id": {"path": "..."} | {"option": "..."} | "skip"}}'
].join("\n");

async function aiMap(request, settings) {
  const baseUrl = (settings.apiBaseUrl || "https://api.deepseek.com/v1").replace(/\/$/, "");
  const body = {
    model: settings.model || "deepseek-chat",
    temperature: 0,
    max_tokens: 1500,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: JSON.stringify({ fields: request.fields, profile: request.profileDigest }) }
    ]
  };

  const response = await fetch(baseUrl + "/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + settings.apiKey
    },
    body: JSON.stringify(body)
  });

  const payload = await response.json();
  if (!response.ok) {
    throw new Error((payload && payload.error && payload.error.message) || "AI 接口返回 " + response.status);
  }
  const parsed = parseModelJson(payload.choices && payload.choices[0] && payload.choices[0].message && payload.choices[0].message.content);
  return { mapping: parsed.mapping || {} };
}

const SELF_DESC_PROMPT = [
  "你是求职者的自我描述撰写助手。基于候选人资料和目标岗位,用第一人称中文写一段 150-200 字的自我描述:",
  "第一句给出与岗位匹配的定位,中间 2-3 句用资料里的具体经历/技能作为证据(必须来自资料,严禁编造),最后一句表达对该岗位的意愿。",
  "语气自然、专业、具体,不堆砌套话,不用 Markdown,不分段。",
  '输出严格 JSON,不要任何多余文字:{"text": "..."}'
].join("\n");

async function aiGenerateText(message, settings) {
  const baseUrl = (settings.apiBaseUrl || "https://api.deepseek.com/v1").replace(/\/$/, "");
  const response = await fetch(baseUrl + "/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + settings.apiKey },
    body: JSON.stringify({
      model: settings.model || "deepseek-chat",
      temperature: 0.3,
      max_tokens: 600,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SELF_DESC_PROMPT },
        { role: "user", content: JSON.stringify({ candidateProfile: message.profileDigest, targetJob: message.job }) }
      ]
    })
  });
  const payload = await response.json();
  if (!response.ok) {
    throw new Error((payload && payload.error && payload.error.message) || "AI 接口返回 " + response.status);
  }
  const parsed = parseModelJson(payload.choices && payload.choices[0] && payload.choices[0].message && payload.choices[0].message.content);
  if (!parsed.text) throw new Error("模型没有返回 text 字段");
  return { text: String(parsed.text) };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "aiGenerate") {
    chrome.storage.local.get(["jaf_settings"], async (data) => {
      const settings = Object.assign({}, self.JAF_DEFAULT_SETTINGS, data.jaf_settings || {});
      if (!settings.apiKey) {
        sendResponse({ error: "未配置 API Key" });
        return;
      }
      try {
        sendResponse(await aiGenerateText(message, settings));
      } catch (e) {
        sendResponse({ error: e.message });
      }
    });
    return true;
  }

  if (message && message.type === "getAsset") {
    // 只允许取 assets/ 下的打包附件;由 background 读取,避免把文件暴露给所有网站
    (async () => {
      try {
        if (!/^assets\/[^/]+$/.test(message.path)) throw new Error("非法附件路径");
        const resp = await fetch(chrome.runtime.getURL(message.path));
        if (!resp.ok) throw new Error("附件不存在: " + message.path);
        const bytes = new Uint8Array(await resp.arrayBuffer());
        let bin = "";
        const chunk = 0x8000;
        for (let i = 0; i < bytes.length; i += chunk) {
          bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
        }
        sendResponse({ b64: btoa(bin) });
      } catch (e) {
        sendResponse({ error: e.message });
      }
    })();
    return true;
  }

  if (message && message.type === "aiMap") {
    chrome.storage.local.get(["jaf_settings"], async (data) => {
      const settings = Object.assign({}, self.JAF_DEFAULT_SETTINGS, data.jaf_settings || {});
      if (!settings.apiKey) {
        sendResponse({ mapping: {}, error: "未配置 API Key" });
        return;
      }
      try {
        sendResponse(await aiMap(message, settings));
      } catch (e) {
        sendResponse({ mapping: {}, error: e.message });
      }
    });
    return true; // 异步 sendResponse
  }
});
