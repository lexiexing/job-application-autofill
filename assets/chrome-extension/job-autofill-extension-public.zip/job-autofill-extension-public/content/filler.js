// 填写执行:兼容 React/Vue 受控组件的赋值方式、原生/自定义下拉、单选多选、高亮标注。
(function (root) {
  const JAF = (root.JAF = root.JAF || {});

  const norm = (t) => JAF.normalizeDesc(t);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 用原生 setter 赋值再派发事件,让 React/Vue 受控组件感知到输入
  JAF.setNativeValue = function (el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype
      : el.tagName === "SELECT" ? HTMLSelectElement.prototype
      : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  };

  JAF.highlight = function (el, ok) {
    const target = el.closest("[class*='form-item']") || el;
    target.style.outline = ok ? "2px solid #34c759" : "2px solid #ff9500";
    target.style.outlineOffset = "1px";
  };

  // 选项文本匹配:全等 > 选项含目标 > 目标含选项(如目标"硕士研究生"匹配选项"硕士")
  JAF.matchOptionIndex = function (optionTexts, targetText) {
    const t = norm(targetText);
    if (!t) return -1;
    let idx = optionTexts.findIndex((o) => norm(o) === t);
    if (idx >= 0) return idx;
    idx = optionTexts.findIndex((o) => norm(o) && norm(o).includes(t));
    if (idx >= 0) return idx;
    idx = optionTexts.findIndex((o) => norm(o) && t.includes(norm(o)) && norm(o).length >= 2);
    if (idx >= 0) return idx;
    // 公共前缀兜底:目标"硕士研究生"可匹配选项"硕士及以上"
    for (let len = Math.min(t.length, 8); len >= 2; len--) {
      const prefix = t.slice(0, len);
      idx = optionTexts.findIndex((o) => norm(o).includes(prefix));
      if (idx >= 0) return idx;
    }
    return -1;
  };

  JAF.fillText = function (field, value) {
    JAF.setNativeValue(field.el, value);
    return field.el.value === value || field.el.value.length > 0;
  };

  JAF.fillSelect = function (field, targetText) {
    const el = field.el;
    const texts = Array.from(el.options).map((o) => o.textContent.trim());
    const idx = JAF.matchOptionIndex(texts, targetText);
    if (idx < 0) return false;
    const proto = HTMLSelectElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "selectedIndex").set.call(el, idx);
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("input", { bubbles: true }));
    return true;
  };

  JAF.fillRadioOrCheckbox = function (field, targets) {
    const wanted = Array.isArray(targets) ? targets : [targets];
    let clicked = 0;
    for (const want of wanted) {
      const idx = JAF.matchOptionIndex(field.options, want);
      if (idx >= 0 && field.groupEls[idx] && !field.groupEls[idx].checked) {
        field.groupEls[idx].click();
        clicked++;
      } else if (idx >= 0 && field.groupEls[idx] && field.groupEls[idx].checked) {
        clicked++;
      }
    }
    return clicked > 0;
  };

  // 自定义下拉:点击触发 → 双路找选项(类名快路径 + MutationObserver 捕获新增 portal 弹层)→ 点击匹配项。
  const OPTION_SELECTOR = [
    "[role='option']",
    ".el-select-dropdown__item",
    ".ant-select-item-option",
    ".ivu-select-item",
    "[class*='dropdown'] li",
    "[class*='select-option']",
    "[class*='option-item']",
    "[class*='menu-item']"
  ].join(",");
  const isVis = (n) => {
    const r = n.getBoundingClientRect();
    return r.width > 4 && r.height > 4;
  };
  const clickHard = (n) => {
    ["mousedown", "mouseup", "click"].forEach((t) => n.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true })));
  };
  // 在新增子树里找"承载短文本的最深元素"作为候选选项(不依赖任何类名约定)
  const collectOptionNodes = (roots) => {
    const out = [];
    const seen = new Set();
    for (const root of roots) {
      if (!root.isConnected || !root.querySelectorAll) continue;
      const all = [root].concat(Array.from(root.querySelectorAll("*")));
      for (const n of all) {
        if (seen.has(n)) continue;
        const t = (n.textContent || "").trim();
        if (!t || t.length > 24) continue;
        if (n.children.length >= 2) continue; // 多子元素的是选项容器,不是选项本身
        if (Array.from(n.children).some((c) => (c.textContent || "").trim() === t)) continue; // 有等文子元素→取更深的
        if (!isVis(n)) continue;
        seen.add(n);
        out.push(n);
      }
    }
    return out;
  };

  // targets 可以是单个文本或数组(多选下拉逐个点)
  JAF.fillCustomDropdown = async function (field, targets) {
    const wanted = (Array.isArray(targets) ? targets : [targets]).filter(Boolean);
    if (!wanted.length) return false;
    const el = field.el;

    const before = new Set(Array.from(document.querySelectorAll(OPTION_SELECTOR)).filter(isVis));
    const added = [];
    const mo = new MutationObserver((muts) => {
      muts.forEach((m) => m.addedNodes.forEach((n) => { if (n.nodeType === 1) added.push(n); }));
    });
    mo.observe(document.body, { childList: true, subtree: true });

    try {
      const trigger = el.closest("[class*='select'],[class*='Select'],[class*='dropdown'],[class*='picker']") || el;
      clickHard(trigger);
      if (el.focus) el.focus();

      let clicked = 0;
      for (let tries = 0; tries < 8; tries++) {
        await sleep(220);
        const classic = Array.from(document.querySelectorAll(OPTION_SELECTOR)).filter((o) => isVis(o) && !before.has(o));
        const pool = classic.length ? classic : collectOptionNodes(added);
        if (!pool.length) continue;
        const texts = pool.map((o) => (o.textContent || "").trim());
        for (const want of wanted) {
          const idx = JAF.matchOptionIndex(texts, want);
          if (idx >= 0) {
            clickHard(pool[idx]);
            clicked++;
            await sleep(120);
          }
        }
        break; // 弹层已出现:无论命中与否,结束轮询
      }
      if (clicked) {
        await sleep(80);
        document.body.click(); // 收起可能残留的弹层
      }
      return clicked > 0;
    } finally {
      mo.disconnect();
    }
  };

  // 控件当前已有值(简历解析回填/用户手填/页面预填)则默认跳过,不覆盖
  JAF.hasExistingValue = function (field) {
    const el = field.el;
    switch (field.kind) {
      case "text": case "textarea": case "date": case "month":
      case "customDropdown": case "customDate": case "readonly":
        return !!String(el.value || "").trim();
      case "select":
        return el.selectedIndex > 0 && !!el.value;
      case "radio": case "checkbox":
        return (field.groupEls || []).some((g) => g.checked);
      case "ymPair":
        return !!(String(field.els.yearEl.value || "").trim() || (field.els.presentEl && field.els.presentEl.checked));
      case "file":
        return !!(el.files && el.files.length);
      default:
        return false;
    }
  };

  // ===== 附件上传 =====
  const MIME = {
    pdf: "application/pdf", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg",
    doc: "application/msword", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    txt: "text/plain"
  };
  const extOf = (path) => path.slice(path.lastIndexOf(".") + 1).toLowerCase();
  const acceptOk = (accept, path) => {
    if (!accept || !accept.trim()) return true;
    const ext = extOf(path);
    const mime = MIME[ext] || "";
    return accept.toLowerCase().split(",").some((a) => {
      a = a.trim();
      if (!a) return false;
      if (a === "." + ext) return true;
      if (a === mime) return true;
      if (a.endsWith("/*") && mime.startsWith(a.slice(0, -1))) return true;
      return false;
    });
  };

  // 按字段描述配对附件(JAF_ATTACHMENTS 里第一个命中的)
  JAF.matchAttachment = function (field) {
    const desc = norm(field.desc);
    if (!desc) return null;
    for (const att of root.JAF_ATTACHMENTS || []) {
      const m = att.match || {};
      if (m.all && !m.all.every((w) => desc.includes(norm(w)))) continue;
      if (m.any && !m.any.some((w) => desc.includes(norm(w)))) continue;
      if (!m.all && !m.any) continue;
      return att;
    }
    return null;
  };

  // 通过 background 取扩展包内文件的 base64(避免把文件暴露成 web_accessible_resources)
  const getAsset = (path) =>
    new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "getAsset", path }, (resp) => {
        if (chrome.runtime.lastError || !resp) resolve({ error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || "无响应" });
        else resolve(resp);
      });
    });

  JAF.fillFile = async function (field, att) {
    const el = field.el;
    const usable = att.files.filter((f) => acceptOk(el.accept, f));
    if (!usable.length) return { status: "manual", reason: "该控件只接受 " + el.accept + ",没有匹配格式的附件(" + att.label + ")" };
    const chosen = att.multiFiles && el.multiple ? usable : [usable[0]];

    const dt = new DataTransfer();
    for (const path of chosen) {
      const resp = await getAsset(path);
      if (resp.error) return { status: "manual", reason: "读取附件失败: " + resp.error };
      const bytes = Uint8Array.from(atob(resp.b64), (c) => c.charCodeAt(0));
      const name = chosen.length === 1 && att.rename ? att.rename : path.split("/").pop();
      dt.items.add(new File([bytes], name, { type: MIME[extOf(path)] || "application/octet-stream" }));
    }
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "files").set;
    setter.call(el, dt.files);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    const names = Array.from(dt.files).map((f) => f.name).join("、");
    return el.files.length ? { status: "filled", value: names } : { status: "manual", reason: "文件未能写入控件" };
  };

  // 单个字段的填写调度。resolved: {value, choice, date, multiChoice, skip, attachment}
  JAF.fillField = async function (field, resolved, opts) {
    if (resolved.skip) return { status: "skipped", reason: resolved.skip };
    if (!(opts && opts.overwrite) && JAF.hasExistingValue(field)) {
      return { status: "skipped", reason: "已有内容,未覆盖(需要覆盖请在弹窗勾选)" };
    }
    const value = resolved.value;

    // 日期精度保护:控件要求到"日"而资料只有年月时,不编造
    if (resolved.date) {
      const onlyMonth = /^\d{4}-\d{2}$/.test(value);
      if (field.kind === "date" && onlyMonth) return { status: "skipped", reason: "资料只有年月(" + value + "),不编造具体日期" };
      if (field.kind === "month" && !onlyMonth) return JAF.fillText(field, value.slice(0, 7)) ? { status: "filled", value: value.slice(0, 7) } : { status: "manual", reason: "写入失败" };
      if (value === "至今" && (field.kind === "date" || field.kind === "month" || field.kind === "customDate")) {
        return { status: "skipped", reason: "结束时间为\"至今\",请手动选择" };
      }
    }

    switch (field.kind) {
      case "text":
      case "textarea":
      case "date":
      case "month":
        return JAF.fillText(field, value) ? { status: "filled", value } : { status: "manual", reason: "写入失败" };
      case "select":
        if (resolved.multiChoice) {
          for (const v of resolved.multiChoice) if (JAF.fillSelect(field, v)) return { status: "filled", value: v };
          return { status: "manual", reason: "下拉中没有匹配的城市选项" };
        }
        return JAF.fillSelect(field, value) ? { status: "filled", value } : { status: "manual", reason: "下拉选项中没有\"" + value + "\"" };
      case "radio":
        return JAF.fillRadioOrCheckbox(field, value) ? { status: "filled", value } : { status: "manual", reason: "选项中没有\"" + value + "\"" };
      case "checkbox": {
        const targets = resolved.multiChoice || [value];
        return JAF.fillRadioOrCheckbox(field, targets) ? { status: "filled", value: targets.join("、") } : { status: "manual", reason: "选项不匹配" };
      }
      case "customDropdown":
      case "readonly": {
        const targets = resolved.multiChoice || [value];
        const ok = await JAF.fillCustomDropdown(field, targets);
        if (ok) return { status: "filled", value: targets.join("、") };
        return { status: "manual", reason: (field.kind === "readonly" ? "只读控件" : "自定义下拉") + "未能自动选择(建议值: " + targets.join("、") + ")" };
      }
      case "customDate":
        return { status: "manual", reason: "日期选择器请手动选择(建议值: " + value + ")" };
      case "ymPair": {
        if (value === "至今") {
          if (field.els.presentEl) {
            if (!field.els.presentEl.checked) field.els.presentEl.click();
            return { status: "filled", value: "至今" };
          }
          return { status: "skipped", reason: "结束时间为\"至今\"且行内没有至今勾选,请手动处理" };
        }
        const m = /^(\d{4})-(\d{1,2})/.exec(String(value || ""));
        if (!m) return { status: "skipped", reason: "日期无法拆成年/月: " + value };
        JAF.setNativeValue(field.els.yearEl, m[1]);
        JAF.setNativeValue(field.els.monthEl, String(Number(m[2])));
        return { status: "filled", value: m[1] + "年" + Number(m[2]) + "月" };
      }
      case "file":
        if (resolved.attachment) return JAF.fillFile(field, resolved.attachment);
        return { status: "skipped", reason: "没有配对的附件,请手动上传" };
      default:
        return { status: "manual", reason: "未知控件类型" };
    }
  };
})(typeof self !== "undefined" ? self : globalThis);
