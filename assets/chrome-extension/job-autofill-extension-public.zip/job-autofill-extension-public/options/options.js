// 设置页:按分区自动生成表单,可增删多段经历,保存到 chrome.storage.local。
const LABELS = {
  chineseName: "中文姓名", englishName: "英文名", gender: "性别", ethnicity: "民族",
  birthDate: "出生日期", idType: "证件类型", idNumber: "证件号码", nationality: "国籍/地区",
  nativePlace: "籍贯", currentCity: "现居住地", mobile: "手机", email: "邮箱", qq: "QQ",
  wechat: "微信号", website: "个人网站", availability: "到岗时间", internshipDuration: "实习时长",
  acceptCityAdjustment: "接受城市调剂", cityPriority: "意向城市优先级(顿号分隔)",
  school: "学校", schoolType: "学校类型", degree: "学历", eduType: "培养方式", college: "学院",
  major: "专业", direction: "研究方向", location: "所在城市", start: "开始时间(YYYY-MM)",
  end: "结束时间(YYYY-MM)", gpa: "GPA", rank: "排名", studentNumber: "学号", advisor: "导师",
  mainCourses: "主修课程", minor: "辅修",
  company: "公司", department: "部门", role: "职位/角色", description: "描述",
  name: "名称", date: "日期(YYYY-MM-DD)", score: "分数", skills: "技能"
};
const SECTIONS = [
  { key: "personal", title: "基本信息", array: false },
  { key: "education", title: "教育经历", array: true },
  { key: "internships", title: "实习经历", array: true },
  { key: "projects", title: "项目/在校实践", array: true },
  { key: "awards", title: "获奖情况", array: true },
  { key: "certificates", title: "证书", array: true }
];
const WIDE_KEYS = ["description", "mainCourses", "skills"];

let profile = null;
const $ = (id) => document.getElementById(id);
const root = $("profile-root");

function fieldHtml(path, key, value) {
  const label = LABELS[key] || key;
  const wide = WIDE_KEYS.includes(key);
  const val = Array.isArray(value) ? value.join("、") : value;
  const esc = String(val == null ? "" : val).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
  if (key === "description") {
    return '<div class="field wide"><label>' + label + '</label><textarea data-path="' + path + '">' + esc + "</textarea></div>";
  }
  return '<div class="field' + (wide ? " wide" : "") + '"><label>' + label + '</label><input data-path="' + path + '" value="' + esc + '" /></div>';
}

function render() {
  let html = "";
  for (const sec of SECTIONS) {
    html += "<h2>" + sec.title + "</h2>";
    if (!sec.array) {
      html += '<fieldset><div class="grid">';
      for (const [k, v] of Object.entries(profile[sec.key])) html += fieldHtml(sec.key + "." + k, k, v);
      html += "</div></fieldset>";
    } else {
      profile[sec.key].forEach((rec, i) => {
        html += '<fieldset><div class="rec-head"><legend>第 ' + (i + 1) + ' 段</legend>' +
          '<button class="mini del" data-del="' + sec.key + ":" + i + '">删除这段</button></div><div class="grid">';
        for (const [k, v] of Object.entries(rec)) html += fieldHtml(sec.key + "." + i + "." + k, k, v);
        html += "</div></fieldset>";
      });
      html += '<button class="mini" data-add="' + sec.key + '">＋ 添加一段</button>';
    }
  }
  html += "<h2>技能</h2><fieldset><div class=\"grid\">" + fieldHtml("skills", "skills", profile.skills) + "</div></fieldset>";
  root.innerHTML = html;
}

function collect() {
  root.querySelectorAll("[data-path]").forEach((el) => {
    const keys = el.dataset.path.split(".");
    let node = profile;
    for (let i = 0; i < keys.length - 1; i++) node = node[keys[i]];
    const last = keys[keys.length - 1];
    node[last] = last === "cityPriority"
      ? el.value.split(/[、,，\s]+/).filter(Boolean)
      : el.value;
  });
}

root.addEventListener("click", (e) => {
  const add = e.target.dataset && e.target.dataset.add;
  const del = e.target.dataset && e.target.dataset.del;
  if (add) {
    collect();
    const template = profile[add][0] || {};
    const blank = {};
    Object.keys(template).forEach((k) => (blank[k] = ""));
    profile[add].push(blank);
    render();
  } else if (del) {
    if (!confirm("确定删除这段记录?")) return;
    collect();
    const [sec, idx] = del.split(":");
    profile[sec].splice(Number(idx), 1);
    render();
  }
});

function loadSettings(s) {
  $("s-apiKey").value = s.apiKey || "";
  $("s-apiBaseUrl").value = s.apiBaseUrl || "https://api.deepseek.com/v1";
  $("s-model").value = s.model || "deepseek-chat";
  $("s-aiEnabled").value = String(s.aiEnabled !== false);
}

function load() {
  chrome.storage.local.get(["jaf_profile", "jaf_settings"], (data) => {
    profile = data.jaf_profile || JSON.parse(JSON.stringify(self.JAF_DEFAULT_PROFILE));
    loadSettings(Object.assign({}, self.JAF_DEFAULT_SETTINGS, data.jaf_settings || {}));
    render();
  });
}

$("save").addEventListener("click", () => {
  collect();
  const settings = {
    apiKey: $("s-apiKey").value.trim(),
    apiBaseUrl: $("s-apiBaseUrl").value.trim() || "https://api.deepseek.com/v1",
    model: $("s-model").value.trim() || "deepseek-chat",
    aiEnabled: $("s-aiEnabled").value === "true"
  };
  chrome.storage.local.set({ jaf_profile: profile, jaf_settings: settings }, () => {
    const toast = $("toast");
    toast.style.display = "block";
    setTimeout(() => (toast.style.display = "none"), 1500);
  });
});

$("reload").addEventListener("click", load);

$("reset").addEventListener("click", () => {
  if (!confirm("确定把资料恢复成内置默认值?你的修改会丢失(API Key 设置保留)。")) return;
  profile = JSON.parse(JSON.stringify(self.JAF_DEFAULT_PROFILE));
  render();
});

load();
