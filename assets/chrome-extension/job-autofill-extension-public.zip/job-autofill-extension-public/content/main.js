// 编排:读资料 -> 扫描 -> 规则匹配 -> AI 兜底 -> 填写 -> 高亮 -> 返回报告。
// popup 通过 chrome.scripting.executeScript 注入后调用 window.__JAF_RUN__(options)。
(function (root) {
  const JAF = (root.JAF = root.JAF || {});

  // 敏感字段绝不发给 AI,AI 只做"字段->资料键"的映射,取值在本地完成
  const SENSITIVE_KEYS = ["idNumber", "mobile", "qq", "email", "wechat", "birthDate"];

  const getByPath = (obj, path) => {
    try {
      return path.split(".").reduce((acc, key) => (acc == null ? undefined : acc[key]), obj);
    } catch {
      return undefined;
    }
  };

  const buildProfileDigest = (profile, descLimit) => {
    const limit = descLimit || 60;
    const digest = JSON.parse(JSON.stringify(profile));
    SENSITIVE_KEYS.forEach((k) => {
      if (digest.personal && k in digest.personal) digest.personal[k] = "(本地已有,可映射 personal." + k + ")";
    });
    // 长文本截断,降低 token 消耗
    ["internships", "projects"].forEach((sec) => {
      (digest[sec] || []).forEach((rec) => {
        if (rec.description && rec.description.length > limit) rec.description = rec.description.slice(0, limit) + "…";
      });
    });
    return digest;
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // 数页面上已有内容的文本控件,用来探测"简历解析回填"是否发生、何时结束
  const countFilledInputs = () =>
    Array.from(document.querySelectorAll("input[type='text'],input[type='tel'],input[type='email'],input:not([type]),textarea"))
      .filter((i) => String(i.value || "").trim()).length;

  const loadStorage = () =>
    new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.storage) {
        resolve({ profile: root.JAF_DEFAULT_PROFILE, settings: root.JAF_DEFAULT_SETTINGS });
        return;
      }
      chrome.storage.local.get(["jaf_profile", "jaf_settings"], (data) => {
        resolve({
          profile: data.jaf_profile || root.JAF_DEFAULT_PROFILE,
          settings: Object.assign({}, root.JAF_DEFAULT_SETTINGS, data.jaf_settings || {})
        });
      });
    });

  const askAI = (fields, profileDigest) =>
    new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
        resolve(root.__JAF_FAKE_AI__ ? root.__JAF_FAKE_AI__(fields) : { mapping: {} });
        return;
      }
      chrome.runtime.sendMessage(
        {
          type: "aiMap",
          fields: fields.map((f) => ({ id: f.id, desc: f.desc, kind: f.kind, section: f.sectionType, options: (f.options || []).slice(0, 30) })),
          profileDigest
        },
        (resp) => {
          if (chrome.runtime.lastError || !resp) resolve({ mapping: {}, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
          else resolve(resp);
        }
      );
    });

  root.__JAF_RUN__ = async function (options) {
    const opts = options || {};
    const { profile, settings } = await loadStorage();
    const report = { filled: [], skipped: [], manual: [], aiMapped: 0, aiError: "", total: 0 };

    let fields = JAF.scanFields();
    report.total = fields.length;
    if (!fields.length) {
      report.aiError = "页面上没有找到可填写的表单字段";
      return report;
    }

    // 简历优先:页面有"简历"上传控件且还没传过 → 先上传,等网站解析回填,再补剩余字段
    const resumeField = fields.find((f) => {
      if (f.kind !== "file" || (f.el.files && f.el.files.length)) return false;
      const att = JAF.matchAttachment(f);
      return att && att.id === "resume";
    });
    if (resumeField) {
      const beforeCount = countFilledInputs();
      const up = await JAF.fillFile(resumeField, JAF.matchAttachment(resumeField));
      if (up.status === "filled") {
        JAF.highlight(resumeField.el, true);
        report.filled.push({ desc: resumeField.desc.slice(0, 40), via: "attach", value: up.value });
        // 轮询等待解析:字段数增加后连续 3 次(1.5s)不再变化即视为完成,上限 20s
        let last = beforeCount, grew = false, stable = 0;
        for (let t = 0; t < 40; t++) {
          await sleep(500);
          const now = countFilledInputs();
          if (now > last) { grew = true; stable = 0; }
          else if (grew && ++stable >= 3) break;
          last = now;
        }
        report.resumeNote = grew
          ? "简历已上传,网站解析回填了约 " + Math.max(0, last - beforeCount) + " 处(已跳过不覆盖,只补空字段)"
          : "简历已上传(20 秒内未检测到自动解析回填)";
        fields = JAF.scanFields(); // 解析可能新增/回填了字段,重扫
        report.total = fields.length;
      } else {
        JAF.highlight(resumeField.el, false);
        report.manual.push({ desc: resumeField.desc.slice(0, 40), via: "attach", reason: up.reason });
      }
    }

    // 第一层:规则匹配(上传控件走附件配对表)
    const usedCounter = {};
    const planned = []; // {field, resolved, via}
    const unmatched = [];
    const aiGenFields = []; // 自我描述类:按岗位现场生成
    for (const field of fields) {
      if (field.kind === "file") {
        const att = JAF.matchAttachment(field);
        if (att) planned.push({ field, resolved: { attachment: att }, via: "attach" });
        else unmatched.push(field);
        continue;
      }
      const resolved = JAF.matchRule(field, profile, usedCounter, opts.entryOffsets);
      if (resolved && resolved.aiGenerate) { aiGenFields.push(field); continue; }
      if (resolved) planned.push({ field, resolved, via: "rule" });
      else unmatched.push(field);
    }

    // 第二层:AI 兜底(仅发送字段描述+选项+脱敏资料摘要;上传字段 AI 帮不上,不发)
    const aiCandidates = unmatched.filter((f) => f.kind !== "file");
    if (aiCandidates.length && settings.aiEnabled && settings.apiKey) {
      const aiResp = await askAI(aiCandidates, buildProfileDigest(profile));
      if (aiResp.error) report.aiError = aiResp.error;
      const mapping = aiResp.mapping || {};
      for (const field of unmatched) {
        const m = mapping[field.id];
        if (!m || m === "skip") continue;
        if (m.path) {
          const value = getByPath(profile, m.path);
          if (value !== undefined && value !== "" && typeof value !== "object") {
            planned.push({ field, resolved: { value: String(value), choice: !!(field.options && field.options.length), date: /(^|\.)(start|end|date|birthDate)$/.test(m.path) }, via: "ai" });
            report.aiMapped++;
          }
        } else if (m.option && field.options && field.options.length) {
          // AI 只能从页面已有选项里挑,防止编造内容
          const idx = JAF.matchOptionIndex(field.options, m.option);
          if (idx >= 0) {
            planned.push({ field, resolved: { value: field.options[idx], choice: true }, via: "ai" });
            report.aiMapped++;
          }
        }
      }
    }

    // 自我描述类字段:结合页面职位信息用 AI 现场生成(不覆盖已有内容)
    if (aiGenFields.length) {
      const canGen = settings.aiEnabled && settings.apiKey;
      const h1 = document.querySelector("h1,h2,[class*='job-title'],[class*='jobTitle']");
      const jobContext = {
        jobTitle: (h1 ? h1.textContent.trim() : "").slice(0, 60),
        pageTitle: String(document.title || "").slice(0, 80)
      };
      for (const field of aiGenFields) {
        if (JAF.hasExistingValue(field) && !opts.overwrite) {
          report.skipped.push({ desc: field.desc.slice(0, 40), via: "ai-gen", reason: "已有内容,未覆盖" });
          continue;
        }
        if (!canGen) {
          report.skipped.push({ desc: field.desc.slice(0, 40), via: "none", reason: "自我描述需按岗位生成,未配置 API Key,请手动撰写" });
          continue;
        }
        const resp = await new Promise((resolve) => {
          if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
            resolve(root.__JAF_FAKE_AI__ ? { text: "" } : { error: "无扩展环境" });
            return;
          }
          chrome.runtime.sendMessage(
            { type: "aiGenerate", job: jobContext, profileDigest: buildProfileDigest(profile, 220) },
            (r) => {
              if (chrome.runtime.lastError || !r) resolve({ error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || "无返回" });
              else resolve(r);
            }
          );
        });
        if (resp && resp.text) {
          planned.push({ field, resolved: { value: String(resp.text).slice(0, 800) }, via: "ai-gen" });
        } else {
          report.skipped.push({ desc: field.desc.slice(0, 40), via: "ai-gen", reason: "AI 生成失败(" + ((resp && resp.error) || "无返回") + "),请手动撰写" });
        }
      }
    }

    // 执行填写(自定义下拉是异步交互,逐个来)
    for (const item of planned) {
      let result;
      try {
        result = await JAF.fillField(item.field, item.resolved, opts);
      } catch (e) {
        result = { status: "manual", reason: "填写出错: " + e.message };
      }
      const entry = { desc: item.field.desc.slice(0, 40), via: item.via };
      if (result.status === "filled") {
        JAF.highlight(item.field.el, true);
        report.filled.push({ ...entry, value: String(result.value).slice(0, 40) });
      } else if (result.status === "skipped") {
        report.skipped.push({ ...entry, reason: result.reason });
      } else {
        JAF.highlight(item.field.el, false);
        report.manual.push({ ...entry, reason: result.reason });
      }
    }

    // 规则和 AI 都没认出的字段,也列入"需手动"供检查。
    // 例外:desc 长得像"一个值"(纯数字/至今/资料里的短值)的,多半是自定义控件里
    // 已显示所选值的空内胆输入框(值存在框外),不算需手动。
    const shortProfileValues = [];
    (function collect(node) {
      if (typeof node === "string") {
        const n = JAF.normalizeDesc(node);
        if (n && n.length <= 20) shortProfileValues.push(n);
      } else if (Array.isArray(node)) node.forEach(collect);
      else if (node && typeof node === "object") Object.values(node).forEach(collect);
    })(profile);
    const looksLikeValue = (desc) => {
      const d = JAF.normalizeDesc(desc);
      if (!d) return true;
      if (/^\+?\d{1,6}$/.test(d)) return true;
      if (["至今", "良好", "一般", "熟练", "英语", "是", "否"].includes(d)) return true;
      return shortProfileValues.some((v) => v === d || (d.length >= 2 && v.includes(d)));
    };
    const plannedFieldIds = new Set(planned.map((p) => p.field.id));
    for (const field of unmatched) {
      if (plannedFieldIds.has(field.id)) continue;
      if (!field.desc || field.desc.length < 2) continue;
      if (JAF.hasExistingValue(field)) continue; // 已有值(如简历解析回填的自定义控件)不算"需手动"
      if (looksLikeValue(field.desc)) continue;
      JAF.highlight(field.el, false);
      report.manual.push({
        desc: field.desc.slice(0, 40),
        via: "none",
        reason: field.kind === "file" ? "没有配对的附件,请手动上传" : "未识别的字段,请手动填写"
      });
    }

    return report;
  };
})(typeof self !== "undefined" ? self : globalThis);
