const $ = (id) => document.getElementById(id);

$("open-options").addEventListener("click", () => chrome.runtime.openOptionsPage());

const escText = (t) => String(t || "").replace(/[&<>\"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '\"': "&quot;" }[c]));

function populateOffset(id, records, nameKey) {
  const select = $(id);
  const rows = Array.isArray(records) && records.length ? records : [{}];
  select.innerHTML = rows.map((record, index) => {
    const name = record && record[nameKey] ? "（" + escText(record[nameKey]) + "）" : "";
    return '<option value="' + index + '">第' + (index + 1) + "段" + name + "</option>";
  }).join("");
}

chrome.storage.local.get(["jaf_settings", "jaf_profile"], (data) => {
  const s = data.jaf_settings || {};
  $("ai-status").textContent = s.aiEnabled && s.apiKey
    ? "AI 兜底:已启用(" + (s.model || "deepseek-chat") + ")"
    : "AI 兜底:未启用,当前为纯规则模式";
  const profile = data.jaf_profile || {};
  populateOffset("offset-internships", profile.internships, "company");
  populateOffset("offset-education", profile.education, "school");
  populateOffset("offset-projects", profile.projects, "name");
});

function renderReport(report) {
  const box = $("report");
  if (!report) {
    box.innerHTML = '<div class="err">没有收到填写结果,请刷新页面后重试。</div>';
    return;
  }
  const esc = (t) => String(t || "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  let html = '<div class="stat">✅ 已填 ' + report.filled.length + " 项 · ⏭ 留空 " + report.skipped.length + " 项 · ✋ 需手动 " + report.manual.length + " 项" +
    (report.aiMapped ? " · 🤖 AI 识别 " + report.aiMapped + " 项" : "") + "</div>";
  if (report.resumeNote) html += '<div class="item ok"><b>📄 ' + esc(report.resumeNote) + "</b></div>";

  report.filled.forEach((f) => {
    const mark = f.via === "ai-gen" ? "🤖生成·务必检查改写 " : f.via === "attach" ? "📎 " : "";
    html += '<div class="item ok"><span class="d">' + mark + esc(f.desc) + '</span> → <span class="v">' + esc(f.value) + "</span></div>";
  });
  report.skipped.forEach((f) => {
    html += '<div class="item skip"><span class="d">' + esc(f.desc) + '</span><br><span class="v">' + esc(f.reason) + "</span></div>";
  });
  report.manual.forEach((f) => {
    html += '<div class="item manual"><span class="d">' + esc(f.desc) + '</span><br><span class="v">' + esc(f.reason) + "</span></div>";
  });
  if (report.aiError) html += '<div class="err">AI 兜底未生效:' + esc(report.aiError) + "</div>";
  box.innerHTML = html;
}

$("fill").addEventListener("click", async () => {
  const btn = $("fill");
  btn.disabled = true;
  btn.textContent = "正在识别并填写…";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || /^chrome|^edge|^about/.test(tab.url || "")) {
      throw new Error("请先切换到网申页面的标签页再点击填写。");
    }
    const target = { tabId: tab.id };
    await chrome.scripting.executeScript({
      target,
      files: ["data/default-profile.js", "data/attachments.js", "content/rules.js", "content/scanner.js", "content/filler.js", "content/main.js"]
    });
    const entryOffsets = {
      internships: Number($("offset-internships").value),
      education: Number($("offset-education").value),
      projects: Number($("offset-projects").value)
    };
    const [{ result }] = await chrome.scripting.executeScript({
      target,
      func: (offsets, overwrite) => window.__JAF_RUN__({ entryOffsets: offsets, overwrite }),
      args: [entryOffsets, $("overwrite").checked]
    });
    renderReport(result);
  } catch (e) {
    $("report").innerHTML = '<div class="err">' + String(e.message || e).replace(/</g, "&lt;") + "</div>";
  } finally {
    btn.disabled = false;
    btn.textContent = "一键填写当前页面";
  }
});
