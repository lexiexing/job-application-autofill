// 被试公开版不打包任何个人附件。
// 简历、成绩单、证书和作品集由用户在招聘网站中手动选择上传。
(function (root) {
  root.JAF_ATTACHMENTS = [];
})(typeof self !== "undefined" ? self : globalThis);
