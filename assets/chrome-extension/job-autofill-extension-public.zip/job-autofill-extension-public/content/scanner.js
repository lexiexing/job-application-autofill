// 扫描页面表单字段,为每个字段收集"描述文本"、控件类型、选项列表和所属分区。
(function (root) {
  const JAF = (root.JAF = root.JAF || {});

  const isVisible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 2 && rect.height < 2) return false;
    const style = getComputedStyle(el);
    return style.display !== "none" && style.visibility !== "hidden";
  };

  const textOf = (el) => (el ? String(el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 80) : "");

  // 常见表单项容器 class 片段(Element UI / Ant Design / 北森 / Moka / 通用)
  const ITEM_WRAPPER = /form-item|form-group|form-row|field-item|field-wrap|input-item|filter-item|item-content|question/i;
  const LABEL_LIKE = /label|title|name|caption|field-text/i;

  // 提取字段描述:label[for] > aria-label > 包裹的 label > 容器内 label 类元素 > 表格前一格 > placeholder > name/id
  JAF.getFieldDesc = function (el) {
    const parts = [];
    if (el.id) {
      const lab = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (lab) parts.push(textOf(lab));
    }
    if (el.getAttribute("aria-label")) parts.push(el.getAttribute("aria-label"));
    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      labelledBy.split(/\s+/).forEach((id) => parts.push(textOf(document.getElementById(id))));
    }
    const wrappingLabel = el.closest("label");
    if (wrappingLabel) parts.push(textOf(wrappingLabel));

    if (!parts.filter(Boolean).length) {
      // 向上找表单项容器,取其中 label 类元素文本
      let node = el.parentElement;
      for (let depth = 0; node && depth < 5; depth++, node = node.parentElement) {
        const cls = String(node.className || "");
        const lab = node.querySelector("label") ||
          Array.from(node.children).find((c) => LABEL_LIKE.test(String(c.className || "")) && !c.contains(el));
        if (lab && !lab.contains(el)) { parts.push(textOf(lab)); break; }
        if (ITEM_WRAPPER.test(cls)) {
          // 容器内、控件之前的纯文本
          const clone = node.cloneNode(true);
          clone.querySelectorAll("input,select,textarea,button").forEach((n) => n.remove());
          const t = textOf(clone);
          if (t) { parts.push(t.slice(0, 40)); break; }
        }
      }
    }
    if (!parts.filter(Boolean).length) {
      // 表格布局:前一个 td/th
      const cell = el.closest("td");
      if (cell && cell.previousElementSibling) parts.push(textOf(cell.previousElementSibling));
    }
    if (!parts.filter(Boolean).length) {
      // label 在上方/左侧的结构(Moka 等):向上爬,取前置兄弟里的纯短文本
      const sibLab = JAF.prevSiblingLabel(el);
      if (sibLab) parts.push(sibLab);
    }
    if (el.placeholder) parts.push(el.placeholder);
    if (!parts.filter(Boolean).length) parts.push(el.name || el.id || "");
    return parts.filter(Boolean).join(" ").slice(0, 120);
  };

  // label 在上方/左侧(Moka 等):向上爬 ≤6 层,找前置兄弟元素里"不含控件的短文本"
  JAF.prevSiblingLabel = function (el) {
    let node = el;
    for (let depth = 0; node && depth < 6; depth++, node = node.parentElement) {
      let sib = node.previousElementSibling;
      for (let s = 0; sib && s < 3; s++, sib = sib.previousElementSibling) {
        if (sib.matches && sib.matches("input,select,textarea,button")) continue;
        if (sib.querySelector && sib.querySelector("input,select,textarea,button")) continue;
        const t = textOf(sib);
        if (t && t.length >= 2 && t.length <= 20 && /[一-龥a-zA-Z]/.test(t)) return t;
      }
    }
    return "";
  };

  // 分区识别:收集页面上含分区关键词的标题类元素,字段归属于文档顺序上最近的前置标题
  JAF.collectSections = function () {
    const candidates = document.querySelectorAll("h1,h2,h3,h4,h5,h6,legend,[class*='title'],[class*='header'],[class*='section-name']");
    const sections = [];
    candidates.forEach((el) => {
      if (!isVisible(el)) return;
      const t = textOf(el);
      if (!t || t.length > 30) return;
      const type = JAF.detectSectionType(t);
      if (type) sections.push({ el, type, text: t });
    });
    return sections;
  };

  JAF.sectionTypeFor = function (el, sections) {
    let current = "";
    for (const s of sections) {
      const pos = s.el.compareDocumentPosition(el);
      if (pos & Node.DOCUMENT_POSITION_FOLLOWING) current = s.type; // 标题在字段之前
    }
    return current;
  };

  // 判断自定义下拉:readonly/无 name 的文本框且容器 class 像下拉,或 role=combobox
  const looksLikeCustomDropdown = (el) => {
    if (el.getAttribute("role") === "combobox") return true;
    const wrapCls = String((el.parentElement && el.parentElement.className) || "") + " " + String(el.className || "");
    const dropdownish = /select|dropdown|picker|cascader/i.test(wrapCls);
    return dropdownish && (el.readOnly || !el.name);
  };
  const looksLikeDatePicker = (el) => {
    const wrapCls = String((el.parentElement && el.parentElement.className) || "") + " " + String(el.className || "") + " " + String(el.placeholder || "");
    return /date|时间|日期|年月/i.test(wrapCls);
  };

  // 把相邻的"年/月"两个输入框合成一个复合日期字段(Moka 等平台的拆分日期);
  // 同名成对布局按"开始/结束"交替命名以复用日期规则;行内"至今"勾选挂到结束段。
  const composeYmPairs = (fields) => {
    const ph = (f) => (f && f.el ? String(f.el.placeholder || "").trim() : "");
    const isYm = (f, want) => !!f && f.kind === "text" && ph(f) === want;
    const isPresentBox = (f) =>
      !!f && f.kind === "checkbox" &&
      (JAF.normalizeDesc(f.desc).includes("至今") || (f.options || []).some((o) => JAF.normalizeDesc(o).includes("至今")));
    const out = [];
    let run = { label: null, count: -1 };

    for (let i = 0; i < fields.length; i++) {
      const f = fields[i];
      if (!(isYm(f, "年") && isYm(fields[i + 1], "月"))) {
        run = { label: null, count: -1 };
        out.push(f);
        continue;
      }
      const label = JAF.prevSiblingLabel(f.el) || "日期";
      if (run.label === label) run.count++;
      else run = { label, count: 0 };
      const isEndSlot = run.count % 2 === 1;

      // 向后看一位(可能隔一个"至今"勾选):同名的下一对存在 → 开始/结束成对布局
      let j = i + 2;
      let presentField = null;
      if (isPresentBox(fields[j])) { presentField = fields[j]; j++; }
      const hasPartner = !isEndSlot && isYm(fields[j], "年") && isYm(fields[j + 1], "月") &&
        (JAF.prevSiblingLabel(fields[j].el) || "日期") === label;
      const suffix = isEndSlot ? "结束时间" : hasPartner ? "开始时间" : "";

      out.push({
        el: f.el,
        id: f.id,
        desc: (label + suffix).slice(0, 60),
        sectionType: f.sectionType,
        kind: "ymPair",
        options: [],
        els: {
          yearEl: f.el,
          monthEl: fields[i + 1].el,
          presentEl: isEndSlot && presentField ? presentField.groupEls[0] : null
        }
      });
      i++; // 消费"月"
      if (isEndSlot && presentField) i++; // 消费"至今"勾选
    }
    return out;
  };

  // 扫描主入口:返回字段清单
  JAF.scanFields = function () {
    const sections = JAF.collectSections();
    const fields = [];
    const seenRadioGroups = new Set();
    let seq = 0;

    const controls = document.querySelectorAll("input, textarea, select");
    controls.forEach((el) => {
      if (!isVisible(el) || el.disabled) return;
      const type = (el.type || "").toLowerCase();
      if (["hidden", "submit", "button", "reset", "image", "password", "search"].includes(type)) return;
      // 站点自身的搜索框/导航栏控件不属于申请表单,整体排除
      if (el.closest("nav, header, [role='search'], [class*='search'], [class*='Search'], [class*='navbar'], [class*='nav-bar']")) return;

      const base = {
        el,
        id: "f" + seq++,
        desc: "",
        sectionType: JAF.sectionTypeFor(el, sections),
        kind: "",
        options: []
      };

      if (el.tagName === "SELECT") {
        base.kind = "select";
        base.desc = JAF.getFieldDesc(el);
        base.options = Array.from(el.options).map((o) => textOf(o)).filter(Boolean);
      } else if (type === "radio" || type === "checkbox") {
        const groupKey = el.name || (el.closest("[class*='radio-group'],[class*='checkbox-group'],[role='radiogroup']") ? "grp" + seq : "solo" + seq);
        const dedupeKey = el.name ? "name:" + el.name : "el:" + base.id;
        if (el.name && seenRadioGroups.has(dedupeKey)) return;
        seenRadioGroups.add(dedupeKey);

        const groupEls = el.name
          ? Array.from(document.querySelectorAll('input[type="' + type + '"][name="' + CSS.escape(el.name) + '"]'))
          : [el];
        base.kind = type === "radio" ? "radio" : "checkbox";
        base.groupEls = groupEls.filter(isVisible);
        base.options = base.groupEls.map((g) => {
          const lab = g.closest("label") || (g.id && document.querySelector('label[for="' + CSS.escape(g.id) + '"]')) || g.parentElement;
          return textOf(lab);
        });
        // 组描述:容器文本去掉"包着控件的选项 label",保留纯文字 label(即题目)
        const container = el.closest("[class*='group'], [class*='form-item'], [role='radiogroup'], td, fieldset") || (el.parentElement && el.parentElement.parentElement);
        if (container) {
          const clone = container.cloneNode(true);
          clone.querySelectorAll("label").forEach((lab) => {
            if (lab.querySelector("input,select")) lab.remove();
          });
          clone.querySelectorAll("input,select,textarea,button").forEach((n) => n.remove());
          const t = textOf(clone);
          if (t) base.desc = t.slice(0, 60);
        }
        if (!base.desc) base.desc = JAF.getFieldDesc(el);
        void groupKey;
      } else if (el.tagName === "TEXTAREA") {
        base.kind = "textarea";
        base.desc = JAF.getFieldDesc(el);
      } else if (type === "date" || type === "month") {
        base.kind = type;
        base.desc = JAF.getFieldDesc(el);
      } else if (type === "file") {
        return; // 上传控件常被隐藏,统一在第二遍扫描里处理(不受可见性限制)
      } else {
        // text / email / tel / number / url 及自定义组件的内部 input
        base.desc = JAF.getFieldDesc(el);
        if (looksLikeCustomDropdown(el)) base.kind = looksLikeDatePicker(el) ? "customDate" : "customDropdown";
        else if (el.readOnly) base.kind = looksLikeDatePicker(el) ? "customDate" : "readonly";
        else base.kind = "text";
      }

      fields.push(base);
    });

    // 第二遍:上传控件。自定义上传组件普遍把 input[type=file] 藏起来,所以不做可见性过滤。
    document.querySelectorAll('input[type="file"]').forEach((el) => {
      if (el.disabled) return;
      let desc = JAF.getFieldDesc(el);
      if (!desc || desc.length < 2) {
        const box = el.closest("[class*='upload'],[class*='attach'],[class*='file']") || el.parentElement;
        if (box) desc = textOf(box).slice(0, 60);
      }
      fields.push({
        el,
        id: "f" + seq++,
        desc,
        sectionType: JAF.sectionTypeFor(el, sections),
        kind: "file",
        options: []
      });
    });

    return composeYmPairs(fields);
  };
})(typeof self !== "undefined" ? self : globalThis);
