// 公开版默认资料模板。真实资料由用户在设置页填写，并仅保存在 chrome.storage.local。
(function (root) {
  const DEFAULT_PROFILE = {
    personal: {
      chineseName: "",
      englishName: "",
      gender: "",
      ethnicity: "",
      birthDate: "",
      idType: "",
      idNumber: "",
      nationality: "",
      nativePlace: "",
      currentCity: "",
      mobile: "",
      email: "",
      qq: "",
      wechat: "",
      website: "",
      availability: "",
      internshipDuration: "",
      acceptCityAdjustment: "",
      cityPriority: []
    },
    education: [{
      school: "", schoolType: "", degree: "", eduType: "", college: "", major: "",
      direction: "", location: "", start: "", end: "", gpa: "", rank: "",
      studentNumber: "", advisor: "", mainCourses: "", minor: ""
    }],
    internships: [{
      company: "", department: "", role: "", location: "", start: "", end: "", description: ""
    }],
    projects: [{ name: "", role: "", location: "", start: "", end: "", description: "" }],
    awards: [{ name: "", date: "" }],
    certificates: [{ name: "", score: "", date: "" }],
    skills: ""
  };

  const DEFAULT_SETTINGS = {
    apiKey: "",
    apiBaseUrl: "https://api.deepseek.com/v1",
    model: "deepseek-chat",
    aiEnabled: false
  };

  root.JAF_DEFAULT_PROFILE = DEFAULT_PROFILE;
  root.JAF_DEFAULT_SETTINGS = DEFAULT_SETTINGS;
})(typeof self !== "undefined" ? self : globalThis);
