// 规则引擎:关键词字典把页面字段映射到 profile 取值。
// 每条规则: { keys: 命中关键词, not: 排除关键词, section: 限定分区, resolve(profile, entryIndex) }
// resolve 返回 { value } 普通填写 / { value, choice: true } 选项匹配 / { skip: reason } 有意留空 / null 表示本条不适用。
(function (root) {
  const JAF = (root.JAF = root.JAF || {});

  // 归一化字段描述:小写、去空白和常见修饰符号
  JAF.normalizeDesc = function (text) {
    return String(text || "")
      .toLowerCase()
      .replace(/[\s*:：()（）\[\]【】<>《》"'`~!！?？.,，。;；\-_/\\|]+/g, "");
  };

  const has = (desc, words) => words.some((w) => desc.includes(w));

  // 分区识别:标题文本 -> 分区类型
  JAF.detectSectionType = function (text) {
    const t = JAF.normalizeDesc(text);
    if (!t) return "";
    if (has(t, ["实习", "工作经历", "工作经验", "职业经历", "internship", "workexperience"])) return "internship";
    if (has(t, ["教育", "学历信息", "学习经历", "education"])) return "education";
    if (has(t, ["项目", "实践", "校园经历", "社团", "学生工作", "在校经历", "project"])) return "project";
    if (has(t, ["获奖", "奖项", "荣誉", "award"])) return "award";
    if (has(t, ["证书", "语言能力", "外语", "技能证书", "certificate"])) return "certificate";
    if (has(t, ["家庭", "紧急联系"])) return "family";
    return "";
  };

  const edu = (profile, i, key) => {
    const rec = profile.education[Math.min(i, profile.education.length - 1)];
    return rec ? rec[key] || "" : "";
  };
  const intern = (profile, i, key) => {
    const rec = profile.internships[Math.min(i, profile.internships.length - 1)];
    return rec ? rec[key] || "" : "";
  };
  const proj = (profile, i, key) => {
    const rec = profile.projects[Math.min(i, profile.projects.length - 1)];
    return rec ? rec[key] || "" : "";
  };

  const val = (v) => (v ? { value: v } : null);
  const choice = (v) => (v ? { value: v, choice: true } : null);
  const certificateLanguage = (profile) => {
    const text = (profile.certificates || []).map((c) => c.name || "").join(" ");
    if (/英语|cet|toefl|ielts/i.test(text)) return "英语";
    if (/日语|jlpt/i.test(text)) return "日语";
    if (/德语|testdaf/i.test(text)) return "德语";
    if (/法语|delf|dalf/i.test(text)) return "法语";
    return "";
  };
  const certificateLevel = (profile) => {
    const text = (profile.certificates || []).map((c) => c.name || "").join(" ");
    if (/六级|cet[-\s]?6/i.test(text)) return "CET-6";
    if (/四级|cet[-\s]?4/i.test(text)) return "CET-4";
    return "";
  };

  // 规则按数组顺序匹配,先命中先得。范围窄、更具体的规则放前面。
  JAF.RULES = [
    // ===== 明确留空的字段 =====
    { id: "referral", keys: ["推荐码", "内推码", "推荐人码", "referralcode"], resolve: () => ({ skip: "按资料要求留空(推荐码不填)" }) },
    { id: "publication", keys: ["论文", "专著", "出版物", "publication"], resolve: () => ({ skip: "资料中没有可核实的论文或出版物" }) },
    // ===== 资料中没有的字段,留空并报告 =====
    { id: "political", keys: ["政治面貌"], resolve: () => ({ skip: "资料中没有政治面貌,请手动选择" }) },
    { id: "marriage", keys: ["婚姻", "婚育"], resolve: () => ({ skip: "资料中没有婚姻状况" }) },
    { id: "health", keys: ["健康状况", "身体状况"], resolve: () => ({ skip: "资料中没有健康状况" }) },
    { id: "heightWeight", keys: ["身高", "体重"], resolve: () => ({ skip: "资料中没有身高体重" }) },
    { id: "salary", keys: ["期望薪资", "薪资要求", "期望月薪", "薪酬"], resolve: () => ({ skip: "资料中没有期望薪资,请手动填写" }) },
    { id: "selfEval", keys: ["自我评价", "自我介绍", "个人评价", "个人总结", "自我描述"], resolve: () => ({ aiGenerate: true }) },
    { id: "emergency", keys: ["紧急联系"], resolve: () => ({ skip: "资料中没有紧急联系人" }) },

    // ===== 偏好类 =====
    { id: "cityAdjust", keys: ["调剂"], resolve: (p) => choice(p.personal.acceptCityAdjustment) },
    { id: "cities", keys: ["意向城市", "期望城市", "意向工作地", "期望工作地", "期望地点", "意向地点"], resolve: (p) => ({ multiChoice: p.personal.cityPriority }) },
    { id: "availability", keys: ["到岗", "入职时间", "多久到岗", "何时到岗"], section: [""], resolve: (p) => val(p.personal.availability) },
    { id: "duration", keys: ["实习时长", "实习期", "可实习", "实习时间"], not: ["经历"], section: [""], resolve: (p) => val(p.personal.internshipDuration) },
    { id: "daysPerWeek", keys: ["每周天数", "每周出勤", "一周几天", "每周实习"], resolve: () => ({ skip: "资料中没有明确的每周出勤天数,请手动确认" }) },

    // ===== 个人基本信息 =====
    { id: "englishName", keys: ["英文名", "englishname"], resolve: (p) => val(p.personal.englishName) },
    { id: "pinyin", keys: ["拼音"], resolve: () => ({ skip: "资料中没有姓名拼音格式,请手动填写" }) },
    { id: "name", keys: ["姓名", "真实姓名", "候选人姓名", "name"], not: ["英文", "拼音", "紧急", "联系人", "家长", "父", "母", "推荐人", "username", "公司", "学校", "项目", "证书", "奖", "银行", "文件", "filename"], resolve: (p) => val(p.personal.chineseName) },
    { id: "gender", keys: ["性别", "gender"], resolve: (p) => choice(p.personal.gender) },
    { id: "ethnicity", keys: ["民族"], resolve: (p) => choice(p.personal.ethnicity) },
    { id: "birth", keys: ["出生", "生日", "birthday", "birthdate"], resolve: (p) => ({ value: p.personal.birthDate, date: true }) },
    { id: "idType", keys: ["证件类型"], resolve: (p) => choice(p.personal.idType) },
    { id: "idNumber", keys: ["身份证号", "证件号", "身份证", "idcard", "idnumber"], not: ["类型"], resolve: (p) => val(p.personal.idNumber) },
    { id: "nationality", keys: ["国籍", "国家地区", "nationality"], resolve: (p) => choice(p.personal.nationality) },
    { id: "nativePlace", keys: ["籍贯", "户籍", "户口"], resolve: (p) => choice(p.personal.nativePlace) },
    { id: "currentCity", keys: ["现居", "居住地", "常住", "目前所在", "现所在", "所在城市", "当前城市"], resolve: (p) => choice(p.personal.currentCity) },
    { id: "email", keys: ["邮箱", "电子邮件", "email", "mail"], resolve: (p) => val(p.personal.email) },
    { id: "qq", keys: ["qq"], resolve: (p) => val(p.personal.qq) },
    { id: "wechat", keys: ["微信", "wechat", "weixin"], resolve: (p) => val(p.personal.wechat) },
    { id: "mobile", keys: ["手机", "电话", "联系方式", "phone", "mobile", "tel"], not: ["紧急", "家长", "父", "母", "固定", "座机", "公司电话"], resolve: (p) => val(p.personal.mobile) },
    { id: "website", keys: ["个人网站", "个人主页", "作品集链接", "作品链接", "主页链接", "网址", "portfolio", "website", "homepage", "url"], resolve: (p) => val(p.personal.website) },

    // ===== 语言能力 =====
    { id: "langType", keys: ["语言类型", "语言名称", "外语语种", "语种"], resolve: (p) => choice(certificateLanguage(p)) },
    { id: "langLevel", keys: ["掌握程度", "熟练程度", "听说", "读写", "口语能力", "听力能力"], resolve: () => ({ skip: "资料中没有可核实的语言熟练程度" }) },

    // ===== 教育经历(无分区时默认最高学历=硕士) =====
    { id: "gradTime", keys: ["毕业时间", "毕业年份", "毕业日期"], section: [""], resolve: (p) => ({ value: edu(p, 0, "end"), date: true }) },
    { id: "eduSchool", keys: ["学校", "院校", "毕业院校", "就读院校", "school", "university"], not: ["985", "211", "双一流", "类型", "层次", "是否", "所在地"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "school")) },
    { id: "eduCollege", keys: ["学院", "院系", "所在系", "college", "faculty"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "college")) },
    { id: "eduMajor", keys: ["专业", "major"], not: ["专业排名"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "major")) },
    { id: "eduDegree", keys: ["学历", "学位", "degree"], not: ["最高学历要求"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "degree")) },
    { id: "eduType", keys: ["学习形式", "培养方式", "教育类型", "统招", "全日制", "就读形式"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "eduType")) },
    { id: "eduDirection", keys: ["研究方向", "专业方向"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "direction")) },
    { id: "eduAdvisor", keys: ["导师"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "advisor")) },
    { id: "eduGpa", keys: ["gpa", "绩点", "平均分", "平均成绩", "均分"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "gpa")) },
    { id: "eduRank", keys: ["排名", "rank"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "rank")) },
    { id: "eduStudentNo", keys: ["学号"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "studentNumber")) },
    { id: "eduCourses", keys: ["主修课程", "主要课程", "核心课程"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "mainCourses")) },
    { id: "eduMinor", keys: ["辅修"], section: ["education", ""], resolve: (p, i) => val(edu(p, i, "minor")) },
    { id: "edu985YesNo", keys: ["是否985", "是否211", "是否双一流"], section: ["education", ""], resolve: (p, i, sec, desc) => { const st = edu(p, i, "schoolType"); const want = desc.includes("985") ? "985" : desc.includes("211") ? "211" : "双一流"; return choice(st.includes(want) ? "是" : "否"); } },
    { id: "edu985", keys: ["985", "211", "双一流", "学校类型", "院校类型", "院校层次"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "schoolType")) },
    { id: "eduStart", keys: ["入学时间", "入学日期", "开始时间", "起始时间", "startdate"], section: ["education"], resolve: (p, i) => ({ value: edu(p, i, "start"), date: true }) },
    { id: "eduEnd", keys: ["毕业时间", "毕业日期", "结束时间", "截止时间", "enddate"], section: ["education"], resolve: (p, i) => ({ value: edu(p, i, "end"), date: true }) },
    { id: "eduLocation", keys: ["学校所在地", "就读城市", "院校所在"], section: ["education", ""], resolve: (p, i) => choice(edu(p, i, "location")) },

    // ===== 实习/工作经历 =====
    { id: "inCompany", keys: ["公司", "单位", "企业", "雇主", "company", "employer"], not: ["公司电话", "公司地址"], section: ["internship", ""], resolve: (p, i) => val(intern(p, i, "company")) },
    { id: "inDept", keys: ["部门", "department"], section: ["internship", ""], resolve: (p, i) => val(intern(p, i, "department")) },
    { id: "inRole", keys: ["职位", "岗位", "职务", "职位名称", "position", "title"], not: ["意向", "期望", "应聘", "投递", "关键字", "关键词", "搜索", "search"], section: ["internship", "project", ""], resolve: (p, i, section) => (section === "project" ? val(proj(p, i, "role")) : val(intern(p, i, "role"))) },
    { id: "inDesc", keys: ["工作内容", "工作描述", "职责描述", "实习内容", "工作职责", "主要职责", "内容描述", "岗位职责"], section: ["internship", ""], resolve: (p, i) => val(intern(p, i, "description")) },
    { id: "inStart", keys: ["开始时间", "起始时间", "入职时间", "startdate"], section: ["internship"], resolve: (p, i) => ({ value: intern(p, i, "start"), date: true }) },
    { id: "inEnd", keys: ["结束时间", "离职时间", "截止时间", "enddate"], section: ["internship"], resolve: (p, i) => ({ value: intern(p, i, "end"), date: true }) },
    { id: "inLocation", keys: ["工作地点", "所在地", "工作城市"], section: ["internship", ""], resolve: (p, i) => choice(intern(p, i, "location")) },

    // ===== 项目/在校实践 =====
    { id: "prName", keys: ["项目名称", "实践名称", "经历名称", "社团名称", "组织名称", "projectname"], section: ["project", ""], resolve: (p, i) => val(proj(p, i, "name")) },
    { id: "prRole", keys: ["担任角色", "担任职务", "角色", "所任职务"], section: ["project", ""], resolve: (p, i) => val(proj(p, i, "role")) },
    { id: "prDesc", keys: ["项目描述", "项目内容", "实践内容", "经历描述", "项目职责", "项目中职责", "中职责", "主要工作"], section: ["project", ""], resolve: (p, i) => val(proj(p, i, "description")) },
    { id: "prStart", keys: ["开始时间", "起始时间", "startdate"], section: ["project"], resolve: (p, i) => ({ value: proj(p, i, "start"), date: true }) },
    { id: "prEnd", keys: ["结束时间", "截止时间", "enddate"], section: ["project"], resolve: (p, i) => ({ value: proj(p, i, "end"), date: true }) },

    // ===== 获奖 =====
    { id: "awName", keys: ["奖项名称", "获奖名称", "荣誉名称", "奖励名称"], section: ["award", ""], resolve: (p, i) => { const a = p.awards[i]; return a ? val(a.name) : { skip: "资料中只有" + p.awards.length + "条获奖记录" }; } },
    { id: "awDate", keys: ["获奖时间", "获奖日期", "颁发时间", "获得时间"], section: ["award", ""], resolve: (p, i) => { const a = p.awards[i]; return a ? { value: a.date, date: true } : { skip: "资料中只有" + p.awards.length + "条获奖记录" }; } },

    // ===== 证书 / 语言 / 技能 =====
    { id: "cetScore", keys: ["六级成绩", "六级分数", "cet6成绩", "cet6分数", "英语成绩", "外语成绩", "语言成绩"], resolve: (p) => val(p.certificates[0] && p.certificates[0].score) },
    { id: "language", keys: ["英语水平", "外语水平", "语言能力", "英语等级", "外语等级", "语言等级"], resolve: (p) => choice(certificateLevel(p)) },
    { id: "certName", keys: ["证书名称", "证书", "资格证"], section: ["certificate", ""], resolve: (p, i) => { const c = p.certificates[i]; return c ? val(c.name) : { skip: "资料中只有" + p.certificates.length + "条证书记录" }; } },
    { id: "certDate", keys: ["获得时间", "取得时间", "颁发日期", "发证时间"], section: ["certificate"], resolve: (p, i) => { const c = p.certificates[i]; return c ? { value: c.date, date: true } : null; } },
    { id: "skills", keys: ["技能", "特长", "掌握工具", "软件能力", "skills"], not: ["证书"], resolve: (p) => val(p.skills) }
  ];

  // 条目锚定:同一条目容器里若已填了名称(项目名/公司名/学校名,如简历解析回填的),
  // 反查它对应资料里第几段,以此覆盖"按出现顺序数"的计数器,避免预填场景下的错位。
  JAF.entryAnchorIndex = function (field, profile, sectionType) {
    const recs = sectionType === "project" ? profile.projects
      : sectionType === "internship" ? profile.internships
      : sectionType === "education" ? profile.education : null;
    if (!recs || !recs.length || !field.el) return -1;
    const keyOf = (r) => JAF.normalizeDesc(sectionType === "project" ? r.name : sectionType === "internship" ? r.company : r.school);
    let node = field.el.parentElement;
    for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
      const inputs = node.querySelectorAll("input, textarea");
      if (inputs.length > 40) break; // 爬到整个表单级别了,放弃
      const hits = new Set();
      inputs.forEach((inp) => {
        const v = JAF.normalizeDesc(String(inp.value || "").slice(0, 40));
        if (!v || v.length < 3) return;
        recs.forEach((r, idx) => {
          const k = keyOf(r);
          if (k && (k === v || k.includes(v) || v.includes(k))) hits.add(idx);
        });
      });
      if (hits.size === 1) return Array.from(hits)[0];
      if (hits.size > 1) break; // 容器里出现多段的名称,说明已越过条目边界
    }
    return -1;
  };

  // 给一个字段找匹配规则。field: {desc, sectionType}; usedCounter 记录 (sectionType|ruleId) 出现次数以确定第几段经历。
  JAF.matchRule = function (field, profile, usedCounter, entryOffsets) {
    const desc = JAF.normalizeDesc(field.desc);
    if (!desc) return null;

    for (const rule of JAF.RULES) {
      if (!has(desc, rule.keys)) continue;
      if (rule.not && has(desc, rule.not)) continue;
      if (rule.section && !rule.section.includes(field.sectionType || "")) continue;

      const counterKey = (field.sectionType || "") + "|" + rule.id;
      const seen = usedCounter[counterKey] || 0;
      const offsets = entryOffsets || {};
      const offset =
        field.sectionType === "internship" ? offsets.internships || 0 :
        field.sectionType === "education" ? offsets.education || 0 :
        field.sectionType === "project" ? offsets.projects || 0 : 0;
      const anchor = JAF.entryAnchorIndex(field, profile, field.sectionType || "");
      const entryIndex = anchor >= 0 ? anchor : seen + offset;

      const resolved = rule.resolve(profile, entryIndex, field.sectionType || "", desc);
      if (resolved === null || resolved === undefined) continue;
      usedCounter[counterKey] = seen + 1;
      return { ruleId: rule.id, ...resolved };
    }
    return null;
  };
})(typeof self !== "undefined" ? self : globalThis);
